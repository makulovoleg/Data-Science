a = 2
b = 3
print(a)
print(b)
c = input('Введите число: ')
d = input('Введите число: ')

print(f'Ваши числа {c} {d}')


