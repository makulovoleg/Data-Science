c = str(input('Введите число: '))

sum = int(c) + int(c+c) + int(c+c+c)
print(sum)
