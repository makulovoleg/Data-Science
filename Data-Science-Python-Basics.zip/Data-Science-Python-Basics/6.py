a = 2
b = 3
c = 1
print(f'{c}-й день {a}')
while a < b:
    c += 1
    a = a * 1.1
    print(f'{c}-й день {a:.2f}')



